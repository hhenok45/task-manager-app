# Task Manager App

A modern task management application built with React, TypeScript, and Tailwind CSS.

## Features

- Create, edit, delete, and mark tasks as completed
- Each task has a title, description, due date, and priority level
- Sort tasks by due date, priority, or completion status
- Filter tasks by completion status
- Progress bar showing percentage of completed tasks
- Responsive design for both desktop and mobile
- Mock API for simulating CRUD operations

## Technologies Used

- React
- TypeScript
- Tailwind CSS
- Vite
- UUID for generating unique IDs
- Lucide React for icons

## Getting Started

### Prerequisites

- Node.js (v14 or higher)
- npm or yarn

### Installation

1. Clone the repository
```bash
git clone https://github.com/yourusername/task-manager-app.git
cd task-manager-app
```

2. Install dependencies
```bash
npm install
```

3. Start the development server
```bash
npm run dev
```

4. Open your browser and navigate to `http://localhost:5173`

## Build for Production

```bash
npm run build
```

## Deployment

This app can be easily deployed to Netlify or Vercel.

## Project Structure

```
task-manager-app/
├── public/
├── src/
│   ├── api/
│   │   └── taskApi.ts
│   ├── components/
│   │   ├── Modal.tsx
│   │   ├── TaskControls.tsx
│   │   ├── TaskForm.tsx
│   │   ├── TaskItem.tsx
│   │   └── TaskList.tsx
│   ├── types/
│   │   └── index.ts
│   ├── App.tsx
│   ├── index.css
│   └── main.tsx
├── package.json
├── README.md
└── ...
```

## License

MIT