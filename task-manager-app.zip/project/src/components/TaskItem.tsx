import React, { useState } from 'react';
import { Task, SubTask } from '../types';
import { Edit, Trash2, CheckCircle, Circle, ChevronDown, ChevronUp, CheckSquare, Square, Calendar, Flag } from 'lucide-react';

interface TaskItemProps {
  task: Task;
  onEdit: (task: Task) => void;
  onDelete: (taskId: string) => void;
  onToggleComplete: (task: Task) => void;
  onToggleSubtask: (taskId: string, subtaskId: string) => void;
  darkMode?: boolean;
}

const TaskItem: React.FC<TaskItemProps> = ({ 
  task, 
  onEdit, 
  onDelete, 
  onToggleComplete,
  onToggleSubtask,
  darkMode = false
}) => {
  const [expanded, setExpanded] = useState(false);

  const priorityColors = darkMode ? {
    Low: 'bg-emerald-900/30 text-emerald-400 border-emerald-700',
    Medium: 'bg-amber-900/30 text-amber-400 border-amber-700',
    High: 'bg-rose-900/30 text-rose-400 border-rose-700'
  } : {
    Low: 'bg-emerald-100 text-emerald-800 border-emerald-200',
    Medium: 'bg-amber-100 text-amber-800 border-amber-200',
    High: 'bg-rose-100 text-rose-800 border-rose-200'
  };

  const priorityBorders = darkMode ? {
    Low: 'border-l-emerald-500',
    Medium: 'border-l-amber-500',
    High: 'border-l-rose-500'
  } : {
    Low: 'border-l-emerald-500',
    Medium: 'border-l-amber-500',
    High: 'border-l-rose-500'
  };

  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  const isOverdue = () => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const dueDate = new Date(task.dueDate);
    return !task.completed && dueDate < today;
  };

  const calculateSubtaskProgress = () => {
    if (!task.subtasks || task.subtasks.length === 0) return 0;
    const completed = task.subtasks.filter(subtask => subtask.completed).length;
    return Math.round((completed / task.subtasks.length) * 100);
  };

  const subtaskProgress = calculateSubtaskProgress();
  const hasSubtasks = task.subtasks && task.subtasks.length > 0;

  return (
    <div 
      className={`task-card rounded-xl overflow-hidden transition-all duration-300 ${
        darkMode ? 'bg-slate-800/80 text-white' : 'bg-white'
      } ${
        task.completed 
          ? `border-l-4 ${darkMode ? 'border-l-green-500' : 'border-l-green-500'}` 
          : isOverdue() 
            ? `border-l-4 ${darkMode ? 'border-l-rose-500' : 'border-l-rose-500'}` 
            : `border-l-4 ${priorityBorders[task.priority]}`
      }`}
      style={{
        boxShadow: darkMode 
          ? '0 4px 6px -1px rgba(0, 0, 0, 0.2), 0 2px 4px -2px rgba(0, 0, 0, 0.1)' 
          : '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -2px rgba(0, 0, 0, 0.05)'
      }}
    >
      <div className="p-5">
        <div className="flex items-start justify-between">
          <div className="flex items-start space-x-3 flex-1">
            <button 
              onClick={() => onToggleComplete(task)}
              className={`mt-1 transition-colors duration-200 ${
                darkMode ? 'text-slate-400 hover:text-violet-400' : 'text-slate-500 hover:text-violet-600'
              }`}
              aria-label={task.completed ? "Mark as incomplete" : "Mark as complete"}
            >
              {task.completed ? (
                <CheckCircle className="h-5 w-5 text-green-500" />
              ) : (
                <Circle className="h-5 w-5" />
              )}
            </button>
            
            <div className={task.completed ? 'opacity-60' : ''}>
              <h3 className={`font-semibold text-lg ${
                task.completed 
                  ? 'line-through ' + (darkMode ? 'text-slate-400' : 'text-slate-500') 
                  : darkMode ? 'text-white' : 'text-slate-800'
              }`}>
                {task.title}
              </h3>
              
              {task.description && (
                <p className={`mt-1 text-sm ${darkMode ? 'text-slate-300' : 'text-slate-600'}`}>
                  {task.description}
                </p>
              )}
              
              <div className="mt-3 flex flex-wrap items-center gap-2">
                <span className={`text-xs px-2.5 py-1 rounded-full border ${priorityColors[task.priority]}`}>
                  <span className="flex items-center">
                    <Flag className="h-3 w-3 mr-1" />
                    {task.priority}
                  </span>
                </span>
                
                <span className={`text-xs px-2.5 py-1 rounded-full flex items-center ${
                  isOverdue() 
                    ? darkMode 
                      ? 'bg-rose-900/30 text-rose-400 border border-rose-700' 
                      : 'bg-rose-100 text-rose-800 border border-rose-200'
                    : darkMode 
                      ? 'bg-violet-900/30 text-violet-400 border border-violet-700' 
                      : 'bg-violet-100 text-violet-800 border border-violet-200'
                }`}>
                  <Calendar className="h-3 w-3 mr-1" />
                  {isOverdue() ? 'Overdue' : 'Due'}: {formatDate(task.dueDate)}
                </span>
                
                {task.completed && (
                  <span className={`text-xs px-2.5 py-1 rounded-full flex items-center ${
                    darkMode 
                      ? 'bg-green-900/30 text-green-400 border border-green-700' 
                      : 'bg-green-100 text-green-800 border border-green-200'
                  }`}>
                    <CheckCircle className="h-3 w-3 mr-1" />
                    Completed
                  </span>
                )}
                
                {hasSubtasks && (
                  <span className={`text-xs px-2.5 py-1 rounded-full flex items-center ${
                    darkMode 
                      ? 'bg-purple-900/30 text-purple-400 border border-purple-700' 
                      : 'bg-purple-100 text-purple-800 border border-purple-200'
                  }`}>
                    <CheckSquare className="h-3 w-3 mr-1" />
                    Subtasks: {task.subtasks.filter(st => st.completed).length}/{task.subtasks.length}
                  </span>
                )}
              </div>
              
              {hasSubtasks && (
                <div className="mt-4">
                  <div className="flex justify-between items-center mb-1">
                    <span className={`text-xs ${darkMode ? 'text-slate-400' : 'text-slate-600'}`}>Subtasks Progress</span>
                    <span className={`text-xs font-medium ${darkMode ? 'text-violet-400' : 'text-violet-700'}`}>{subtaskProgress}%</span>
                  </div>
                  <div className={`w-full ${darkMode ? 'bg-slate-700' : 'bg-slate-200'} rounded-full h-1.5`}>
                    <div 
                      className="progress-bar-gradient h-1.5 rounded-full transition-all duration-500 ease-in-out" 
                      style={{ width: `${subtaskProgress}%` }}
                    ></div>
                  </div>
                </div>
              )}
            </div>
          </div>
          
          <div className="flex space-x-1 ml-2">
            <button
              onClick={() => onEdit(task)}
              className={`p-1.5 rounded-full transition-colors ${
                darkMode 
                  ? 'text-slate-400 hover:text-violet-400 hover:bg-slate-700' 
                  : 'text-slate-500 hover:text-violet-600 hover:bg-slate-100'
              }`}
              aria-label="Edit task"
            >
              <Edit className="h-4 w-4" />
            </button>
            
            <button
              onClick={() => onDelete(task.id)}
              className={`p-1.5 rounded-full transition-colors ${
                darkMode 
                  ? 'text-slate-400 hover:text-rose-400 hover:bg-slate-700' 
                  : 'text-slate-500 hover:text-rose-600 hover:bg-slate-100'
              }`}
              aria-label="Delete task"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        </div>
        
        {hasSubtasks && (
          <div className="mt-3">
            <button
              onClick={() => setExpanded(!expanded)}
              className={`flex items-center text-sm transition-colors ${
                darkMode 
                  ? 'text-violet-400 hover:text-violet-300' 
                  : 'text-violet-600 hover:text-violet-800'
              }`}
            >
              {expanded ? (
                <>
                  <ChevronUp className="h-4 w-4 mr-1" />
                  Hide Subtasks
                </>
              ) : (
                <>
                  <ChevronDown className="h-4 w-4 mr-1" />
                  Show Subtasks ({task.subtasks.length})
                </>
              )}
            </button>
          </div>
        )}
      </div>
      
      {expanded && hasSubtasks && (
        <div className={`px-5 py-3 border-t transition-colors ${
          darkMode ? 'bg-slate-700/50 border-slate-700' : 'bg-slate-50 border-slate-100'
        }`}>
          <ul className="space-y-2">
            {task.subtasks.map(subtask => (
              <SubtaskItem 
                key={subtask.id} 
                subtask={subtask} 
                taskId={task.id}
                onToggle={onToggleSubtask}
                darkMode={darkMode}
              />
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

interface SubtaskItemProps {
  subtask: SubTask;
  taskId: string;
  onToggle: (taskId: string, subtaskId: string) => void;
  darkMode?: boolean;
}

const SubtaskItem: React.FC<SubtaskItemProps> = ({ subtask, taskId, onToggle, darkMode = false }) => {
  return (
    <li className="flex items-center animate-slideIn">
      <button
        onClick={() => onToggle(taskId, subtask.id)}
        className={`mr-2 transition-colors ${
          darkMode ? 'text-slate-400 hover:text-violet-400' : 'text-slate-500 hover:text-violet-600'
        }`}
        aria-label={subtask.completed ? "Mark as incomplete" : "Mark as complete"}
      >
        {subtask.completed ? (
          <CheckSquare className="h-4 w-4 text-green-500" />
        ) : (
          <Square className="h-4 w-4" />
        )}
      </button>
      <span className={`text-sm ${
        subtask.completed 
          ? 'line-through ' + (darkMode ? 'text-slate-500' : 'text-slate-500') 
          : darkMode ? 'text-slate-300' : 'text-slate-700'
      }`}>
        {subtask.title}
      </span>
    </li>
  );
};

export default TaskItem;

