import React from 'react';
import { SortOption, FilterOption } from '../types';
import { Plus, SortAsc, Filter, ListFilter, BarChart2 } from 'lucide-react';

interface TaskControlsProps {
  onAddTask: () => void;
  sortOption: SortOption;
  onSortChange: (option: SortOption) => void;
  filterOption: FilterOption;
  onFilterChange: (option: FilterOption) => void;
  completedPercentage: number;
  totalTasks: number;
  completedTasks: number;
  darkMode?: boolean;
}

const TaskControls: React.FC<TaskControlsProps> = ({
  onAddTask,
  sortOption,
  onSortChange,
  filterOption,
  onFilterChange,
  completedPercentage,
  totalTasks,
  completedTasks,
  darkMode = false
}) => {
  return (
    <div className={`glass-effect rounded-xl shadow-lg p-6 mb-6 transition-all duration-300 ${
      darkMode ? 'bg-slate-800/70 text-white' : 'bg-white/70'
    }`}>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <button
          onClick={onAddTask}
          className="btn-primary text-white flex items-center justify-center md:justify-start gap-2 rounded-lg"
        >
          <Plus className="h-5 w-5" />
          <span>Add Task</span>
        </button>
        
        <div className="flex flex-col sm:flex-row gap-3">
          <div className={`flex items-center gap-2 px-3 py-2 rounded-lg border transition-colors ${
            darkMode 
              ? 'bg-slate-700/50 border-slate-600 text-slate-200' 
              : 'bg-slate-50 border-slate-200 text-slate-700'
          }`}>
            <SortAsc className={`h-5 w-5 ${darkMode ? 'text-violet-400' : 'text-violet-500'}`} />
            <select
              value={sortOption}
              onChange={(e) => onSortChange(e.target.value as SortOption)}
              className={`bg-transparent border-none focus:outline-none focus:ring-0 text-sm ${
                darkMode ? 'text-slate-200' : 'text-slate-700'
              }`}
            >
              <option value="dueDate" className={darkMode ? 'bg-slate-700 text-white' : 'bg-white text-slate-700'}>Sort by Due Date</option>
              <option value="priority" className={darkMode ? 'bg-slate-700 text-white' : 'bg-white text-slate-700'}>Sort by Priority</option>
              <option value="status" className={darkMode ? 'bg-slate-700 text-white' : 'bg-white text-slate-700'}>Sort by Status</option>
            </select>
          </div>
          
          <div className={`flex items-center gap-2 px-3 py-2 rounded-lg border transition-colors ${
            darkMode 
              ? 'bg-slate-700/50 border-slate-600 text-slate-200' 
              : 'bg-slate-50 border-slate-200 text-slate-700'
          }`}>
            <ListFilter className={`h-5 w-5 ${darkMode ? 'text-violet-400' : 'text-violet-500'}`} />
            <select
              value={filterOption}
              onChange={(e) => onFilterChange(e.target.value as FilterOption)}
              className={`bg-transparent border-none focus:outline-none focus:ring-0 text-sm ${
                darkMode ? 'text-slate-200' : 'text-slate-700'
              }`}
            >
              <option value="all" className={darkMode ? 'bg-slate-700 text-white' : 'bg-white text-slate-700'}>All Tasks</option>
              <option value="completed" className={darkMode ? 'bg-slate-700 text-white' : 'bg-white text-slate-700'}>Completed</option>
              <option value="pending" className={darkMode ? 'bg-slate-700 text-white' : 'bg-white text-slate-700'}>Pending</option>
            </select>
          </div>
        </div>
      </div>
      
      {/* Progress section */}
      <div className="mt-6 pt-5 border-t border-slate-200 dark:border-slate-700">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-3">
          <div className="flex items-center mb-2 sm:mb-0">
            <BarChart2 className={`h-5 w-5 mr-2 ${darkMode ? 'text-violet-400' : 'text-violet-600'}`} />
            <span className={`text-sm font-medium mr-2 ${darkMode ? 'text-slate-300' : 'text-slate-700'}`}>Progress</span>
            <span className="text-sm font-bold gradient-text">{Math.round(completedPercentage)}%</span>
          </div>
          <div className={`text-sm ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
            <span className={`font-medium ${darkMode ? 'text-violet-400' : 'text-violet-600'}`}>{completedTasks}</span> of <span className="font-medium">{totalTasks}</span> tasks completed
          </div>
        </div>
        <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-3 overflow-hidden">
          <div 
            className="progress-bar-gradient h-3 rounded-full transition-all duration-500 ease-in-out" 
            style={{ width: `${completedPercentage}%` }}
          ></div>
        </div>
      </div>
    </div>
  );
};

export default TaskControls;