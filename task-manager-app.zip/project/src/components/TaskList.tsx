import React from 'react';
import { Task, SortOption, FilterOption } from '../types';
import TaskItem from './TaskItem';
import { ClipboardList } from 'lucide-react';

interface TaskListProps {
  tasks: Task[];
  onEdit: (task: Task) => void;
  onDelete: (taskId: string) => void;
  onToggleComplete: (task: Task) => void;
  onToggleSubtask: (taskId: string, subtaskId: string) => void;
  sortOption: SortOption;
  filterOption: FilterOption;
  darkMode?: boolean;
}

const TaskList: React.FC<TaskListProps> = ({
  tasks,
  onEdit,
  onDelete,
  onToggleComplete,
  onToggleSubtask,
  sortOption,
  filterOption,
  darkMode = false
}) => {
  // Filter tasks based on the selected filter option
  const filteredTasks = tasks.filter(task => {
    if (filterOption === 'all') return true;
    if (filterOption === 'completed') return task.completed;
    if (filterOption === 'pending') return !task.completed;
    return true;
  });

  // Sort tasks based on the selected sort option
  const sortedTasks = [...filteredTasks].sort((a, b) => {
    if (sortOption === 'dueDate') {
      return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
    }
    
    if (sortOption === 'priority') {
      const priorityValues = { High: 3, Medium: 2, Low: 1 };
      return priorityValues[b.priority] - priorityValues[a.priority];
    }
    
    if (sortOption === 'status') {
      return Number(a.completed) - Number(b.completed);
    }
    
    return 0;
  });

  if (sortedTasks.length === 0) {
    return (
      <div className={`glass-effect rounded-xl shadow-lg p-8 text-center animate-fadeIn ${
        darkMode ? 'bg-slate-800/70 text-white' : 'bg-white/70'
      }`}>
        <div className="flex flex-col items-center justify-center">
          <div className={`w-20 h-20 rounded-full flex items-center justify-center mb-4 ${
            darkMode ? 'bg-slate-700' : 'bg-violet-100'
          }`}>
            <ClipboardList className={`h-10 w-10 ${darkMode ? 'text-violet-400' : 'text-violet-600'}`} />
          </div>
          <h3 className={`text-xl font-medium mb-2 ${darkMode ? 'text-white' : 'text-slate-900'}`}>
            No tasks found
          </h3>
          <p className={`${darkMode ? 'text-slate-400' : 'text-slate-500'} mb-4 max-w-xs mx-auto`}>
            Create a new task to get started with your productivity journey!
          </p>
          <div className="w-16 h-1 bg-gradient-to-r from-violet-500 to-indigo-500 rounded-full"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {sortedTasks.map((task, index) => (
        <div 
          key={task.id} 
          className="animate-fadeIn" 
          style={{ animationDelay: `${index * 0.05}s` }}
        >
          <TaskItem
            task={task}
            onEdit={onEdit}
            onDelete={onDelete}
            onToggleComplete={onToggleComplete}
            onToggleSubtask={onToggleSubtask}
            darkMode={darkMode}
          />
        </div>
      ))}
    </div>
  );
};

export default TaskList;