import { Task } from '../types';

// Mock API functions to simulate CRUD operations
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Simulate fetching tasks from an API
export const fetchTasks = async (): Promise<Task[]> => {
  // Simulate API delay
  await delay(500);
  
  // Get tasks from localStorage or return empty array
  const storedTasks = localStorage.getItem('tasks');
  return storedTasks ? JSON.parse(storedTasks) : [];
};

// Simulate creating a new task
export const createTask = async (task: Task): Promise<Task> => {
  await delay(300);
  
  const tasks = await fetchTasks();
  const newTasks = [...tasks, task];
  
  localStorage.setItem('tasks', JSON.stringify(newTasks));
  return task;
};

// Simulate updating a task
export const updateTask = async (updatedTask: Task): Promise<Task> => {
  await delay(300);
  
  const tasks = await fetchTasks();
  const updatedTasks = tasks.map(task => 
    task.id === updatedTask.id ? updatedTask : task
  );
  
  localStorage.setItem('tasks', JSON.stringify(updatedTasks));
  return updatedTask;
};

// Simulate deleting a task
export const deleteTask = async (taskId: string): Promise<void> => {
  await delay(300);
  
  const tasks = await fetchTasks();
  const filteredTasks = tasks.filter(task => task.id !== taskId);
  
  localStorage.setItem('tasks', JSON.stringify(filteredTasks));
};