export type Priority = 'Low' | 'Medium' | 'High';

export interface SubTask {
  id: string;
  title: string;
  completed: boolean;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  dueDate: string;
  priority: Priority;
  completed: boolean;
  subtasks: SubTask[];
}

export type SortOption = 'dueDate' | 'priority' | 'status';
export type FilterOption = 'all' | 'completed' | 'pending';