import React, { useState, useEffect } from 'react';
import { Task, SortOption, FilterOption, SubTask } from './types';
import { fetchTasks, createTask, updateTask, deleteTask } from './api/taskApi';
import TaskList from './components/TaskList';
import TaskForm from './components/TaskForm';
import TaskControls from './components/TaskControls';
import Modal from './components/Modal';
import { CheckCircle, ClipboardList, Moon, Sun } from 'lucide-react';

function App() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | undefined>(undefined);
  
  const [sortOption, setSortOption] = useState<SortOption>('dueDate');
  const [filterOption, setFilterOption] = useState<FilterOption>('all');
  
  const [darkMode, setDarkMode] = useState(false);

  // Calculate completed percentage
  const completedTasks = tasks.filter(task => task.completed).length;
  const completedPercentage = tasks.length > 0
    ? (completedTasks / tasks.length) * 100
    : 0;

  // Toggle dark mode
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // Fetch tasks on component mount
  useEffect(() => {
    const loadTasks = async () => {
      try {
        setIsLoading(true);
        const loadedTasks = await fetchTasks();
        
        // Ensure all tasks have a subtasks array
        const normalizedTasks = loadedTasks.map(task => ({
          ...task,
          subtasks: task.subtasks || []
        }));
        
        setTasks(normalizedTasks);
        setError(null);
      } catch (err) {
        setError('Failed to load tasks. Please try again later.');
        console.error('Error loading tasks:', err);
      } finally {
        setIsLoading(false);
      }
    };

    loadTasks();
  }, []);

  // Handle creating or updating a task
  const handleTaskSubmit = async (task: Task) => {
    try {
      setIsLoading(true);
      
      if (editingTask) {
        // Update existing task
        await updateTask(task);
        setTasks(prevTasks => 
          prevTasks.map(t => t.id === task.id ? task : t)
        );
      } else {
        // Create new task
        await createTask(task);
        setTasks(prevTasks => [...prevTasks, task]);
      }
      
      setIsModalOpen(false);
      setEditingTask(undefined);
    } catch (err) {
      setError('Failed to save task. Please try again.');
      console.error('Error saving task:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Handle deleting a task
  const handleDeleteTask = async (taskId: string) => {
    if (window.confirm('Are you sure you want to delete this task?')) {
      try {
        setIsLoading(true);
        await deleteTask(taskId);
        setTasks(prevTasks => prevTasks.filter(task => task.id !== taskId));
      } catch (err) {
        setError('Failed to delete task. Please try again.');
        console.error('Error deleting task:', err);
      } finally {
        setIsLoading(false);
      }
    }
  };

  // Handle toggling task completion status
  const handleToggleComplete = async (task: Task) => {
    const updatedTask = { 
      ...task, 
      completed: !task.completed,
      // If task is marked as complete, also complete all subtasks
      subtasks: task.completed 
        ? task.subtasks 
        : task.subtasks.map(st => ({ ...st, completed: true }))
    };
    
    try {
      await updateTask(updatedTask);
      setTasks(prevTasks => 
        prevTasks.map(t => t.id === task.id ? updatedTask : t)
      );
    } catch (err) {
      setError('Failed to update task status. Please try again.');
      console.error('Error updating task status:', err);
    }
  };

  // Handle toggling subtask completion status
  const handleToggleSubtask = async (taskId: string, subtaskId: string) => {
    const task = tasks.find(t => t.id === taskId);
    if (!task) return;
    
    const updatedSubtasks = task.subtasks.map(subtask => 
      subtask.id === subtaskId 
        ? { ...subtask, completed: !subtask.completed } 
        : subtask
    );
    
    // Check if all subtasks are completed
    const allSubtasksCompleted = updatedSubtasks.every(subtask => subtask.completed);
    
    const updatedTask = { 
      ...task, 
      subtasks: updatedSubtasks,
      // If all subtasks are completed, mark the task as completed too
      completed: allSubtasksCompleted
    };
    
    try {
      await updateTask(updatedTask);
      setTasks(prevTasks => 
        prevTasks.map(t => t.id === taskId ? updatedTask : t)
      );
    } catch (err) {
      setError('Failed to update subtask status. Please try again.');
      console.error('Error updating subtask status:', err);
    }
  };

  // Open modal for editing a task
  const handleEditTask = (task: Task) => {
    setEditingTask(task);
    setIsModalOpen(true);
  };

  // Open modal for adding a new task
  const handleAddTask = () => {
    setEditingTask(undefined);
    setIsModalOpen(true);
  };

  return (
    <div className={`min-h-screen transition-colors duration-300 ${darkMode ? 'dark bg-slate-900 text-white' : 'bg-slate-50 text-slate-900'}`}>
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <header className="mb-8 text-center relative">
          {/* Dark mode toggle */}
          <div className="absolute right-0 top-0">
            <button 
              onClick={() => setDarkMode(!darkMode)}
              className="p-2 rounded-full transition-all duration-300 hover:bg-slate-200 dark:hover:bg-slate-700"
              aria-label={darkMode ? "Switch to light mode" : "Switch to dark mode"}
            >
              {darkMode ? (
                <Sun className="h-5 w-5 text-yellow-400" />
              ) : (
                <Moon className="h-5 w-5 text-slate-700" />
              )}
            </button>
          </div>
          
          <div className="flex items-center justify-center mb-4">
            <div className="p-4 rounded-full bg-gradient-to-br from-violet-500 to-indigo-600 shadow-lg">
              <ClipboardList className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-4xl font-bold mb-3 gradient-text">Task Manager</h1>
          <p className="text-slate-600 dark:text-slate-300 max-w-md mx-auto">
            Organize your tasks efficiently with our intuitive task management system
          </p>
        </header>

        {/* Error message */}
        {error && (
          <div className="bg-red-50 dark:bg-red-900/30 border-l-4 border-red-500 text-red-700 dark:text-red-300 p-4 mb-6 rounded-md shadow-sm animate-fadeIn">
            <div className="flex">
              <div className="flex-shrink-0">
                <svg className="h-5 w-5 text-red-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                </svg>
              </div>
              <div className="ml-3">
                <p>{error}</p>
              </div>
            </div>
          </div>
        )}

        {/* Task controls (add, sort, filter) */}
        <TaskControls
          onAddTask={handleAddTask}
          sortOption={sortOption}
          onSortChange={setSortOption}
          filterOption={filterOption}
          onFilterChange={setFilterOption}
          completedPercentage={completedPercentage}
          totalTasks={tasks.length}
          completedTasks={completedTasks}
          darkMode={darkMode}
        />

        {/* Loading state */}
        {isLoading && tasks.length === 0 ? (
          <div className="glass-effect rounded-lg shadow-lg p-8 text-center animate-pulse-slow">
            <div className="flex flex-col items-center justify-center">
              <div className="w-12 h-12 rounded-full bg-gradient-to-r from-violet-500 to-indigo-500 animate-spin mb-4 relative">
                <div className="absolute inset-1 rounded-full bg-white dark:bg-slate-900"></div>
              </div>
              <p className="text-slate-600 dark:text-slate-300">Loading your tasks...</p>
            </div>
          </div>
        ) : (
          <TaskList
            tasks={tasks}
            onEdit={handleEditTask}
            onDelete={handleDeleteTask}
            onToggleComplete={handleToggleComplete}
            onToggleSubtask={handleToggleSubtask}
            sortOption={sortOption}
            filterOption={filterOption}
            darkMode={darkMode}
          />
        )}

        {/* Task form modal */}
        <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} darkMode={darkMode}>
          <TaskForm
            onSubmit={handleTaskSubmit}
            initialTask={editingTask}
            onCancel={() => setIsModalOpen(false)}
            darkMode={darkMode}
          />
        </Modal>
      </div>
    </div>
  );
}

export default App;