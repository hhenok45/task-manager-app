import React, { useState, useEffect } from 'react';
import { Task, Priority, SubTask } from '../types';
import { v4 as uuidv4 } from 'uuid';
import { Plus, X, CheckCircle2, Calendar, AlignLeft, Flag, ListChecks } from 'lucide-react';

interface TaskFormProps {
  onSubmit: (task: Task) => void;
  initialTask?: Task;
  onCancel: () => void;
  darkMode?: boolean;
}

const TaskForm: React.FC<TaskFormProps> = ({ onSubmit, initialTask, onCancel, darkMode = false }) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [priority, setPriority] = useState<Priority>('Medium');
  const [completed, setCompleted] = useState(false);
  const [subtasks, setSubtasks] = useState<SubTask[]>([]);
  const [newSubtask, setNewSubtask] = useState('');

  useEffect(() => {
    if (initialTask) {
      setTitle(initialTask.title);
      setDescription(initialTask.description);
      setDueDate(initialTask.dueDate);
      setPriority(initialTask.priority);
      setCompleted(initialTask.completed);
      setSubtasks(initialTask.subtasks || []);
    }
  }, [initialTask]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const task: Task = {
      id: initialTask ? initialTask.id : uuidv4(),
      title,
      description,
      dueDate,
      priority,
      completed,
      subtasks
    };
    
    onSubmit(task);
    
    if (!initialTask) {
      // Reset form if creating a new task
      setTitle('');
      setDescription('');
      setDueDate('');
      setPriority('Medium');
      setCompleted(false);
      setSubtasks([]);
    }
  };

  const addSubtask = () => {
    if (newSubtask.trim() === '') return;
    
    const subtask: SubTask = {
      id: uuidv4(),
      title: newSubtask,
      completed: false
    };
    
    setSubtasks([...subtasks, subtask]);
    setNewSubtask('');
  };

  const removeSubtask = (id: string) => {
    setSubtasks(subtasks.filter(subtask => subtask.id !== id));
  };

  const toggleSubtaskCompletion = (id: string) => {
    setSubtasks(
      subtasks.map(subtask => 
        subtask.id === id 
          ? { ...subtask, completed: !subtask.completed } 
          : subtask
      )
    );
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      addSubtask();
    }
  };

  const getPriorityColor = (p: Priority) => {
    if (darkMode) {
      switch (p) {
        case 'High': return 'text-rose-400 bg-rose-900/30 border-rose-700';
        case 'Medium': return 'text-amber-400 bg-amber-900/30 border-amber-700';
        case 'Low': return 'text-emerald-400 bg-emerald-900/30 border-emerald-700';
      }
    } else {
      switch (p) {
        case 'High': return 'text-rose-700 bg-rose-50 border-rose-200';
        case 'Medium': return 'text-amber-700 bg-amber-50 border-amber-200';
        case 'Low': return 'text-emerald-700 bg-emerald-50 border-emerald-200';
      }
    }
  };

  return (
    <form onSubmit={handleSubmit} className={`p-6 rounded-xl ${darkMode ? 'bg-slate-800' : 'bg-white'}`}>
      <h2 className={`text-2xl font-bold mb-6 ${darkMode ? 'text-white border-b border-slate-700' : 'text-slate-800 border-b border-slate-200'} pb-2`}>
        {initialTask ? 'Edit Task' : 'Create New Task'}
      </h2>
      
      <div className="mb-5">
        <label htmlFor="title" className={`flex items-center text-sm font-medium mb-1.5 ${darkMode ? 'text-slate-300' : 'text-slate-700'}`}>
          <span className="mr-2">Title</span>
          <span className="text-rose-500">*</span>
        </label>
        <div className="relative">
          <input
            type="text"
            id="title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className={`form-input pl-10 ${
              darkMode 
                ? 'bg-slate-700 border-slate-600 text-white focus:ring-violet-500' 
                : 'bg-white border-slate-300 text-slate-900 focus:ring-violet-500'
            }`}
            required
            placeholder="Enter task title"
          />
          <div className="absolute left-3 top-1/2 transform -translate-y-1/2">
            <ListChecks className={`h-5 w-5 ${darkMode ? 'text-slate-400' : 'text-slate-500'}`} />
          </div>
        </div>
      </div>
      
      <div className="mb-5">
        <label htmlFor="description" className={`flex items-center text-sm font-medium mb-1.5 ${darkMode ? 'text-slate-300' : 'text-slate-700'}`}>
          <AlignLeft className={`h-4 w-4 mr-1.5 ${darkMode ? 'text-slate-400' : 'text-slate-500'}`} />
          <span>Description</span>
        </label>
        <textarea
          id="description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          className={`form-input ${
            darkMode 
              ? 'bg-slate-700 border-slate-600 text-white focus:ring-violet-500' 
              : 'bg-white border-slate-300 text-slate-900 focus:ring-violet-500'
          }`}
          rows={3}
          placeholder="Add details about this task"
        />
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-5">
        <div>
          <label htmlFor="dueDate" className={`flex items-center text-sm font-medium mb-1.5 ${darkMode ? 'text-slate-300' : 'text-slate-700'}`}>
            <Calendar className={`h-4 w-4 mr-1.5 ${darkMode ? 'text-slate-400' : 'text-slate-500'}`} />
            <span>Due Date</span>
            <span className="text-rose-500 ml-1">*</span>
          </label>
          <input
            type="date"
            id="dueDate"
            value={dueDate}
            onChange={(e) => setDueDate(e.target.value)}
            className={`form-input ${
              darkMode 
                ? 'bg-slate-700 border-slate-600 text-white focus:ring-violet-500' 
                : 'bg-white border-slate-300 text-slate-900 focus:ring-violet-500'
            }`}
            required
          />
        </div>
        
        <div>
          <label htmlFor="priority" className={`flex items-center text-sm font-medium mb-1.5 ${darkMode ? 'text-slate-300' : 'text-slate-700'}`}>
            <Flag className={`h-4 w-4 mr-1.5 ${darkMode ? 'text-slate-400' : 'text-slate-500'}`} />
            <span>Priority</span>
          </label>
          <div className="flex space-x-2">
            {(['Low', 'Medium', 'High'] as Priority[]).map((p) => (
              <button
                key={p}
                type="button"
                onClick={() => setPriority(p)}
                className={`flex-1 py-2 px-3 rounded-md border text-sm font-medium transition-all duration-200 ${
                  priority === p 
                    ? getPriorityColor(p) 
                    : darkMode 
                      ? 'bg-slate-700 border-slate-600 text-slate-300 hover:bg-slate-600' 
                      : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                {p}
              </button>
            ))}
          </div>
        </div>
      </div>
      
      {initialTask && (
        <div className="mb-5 flex items-center">
          <input
            type="checkbox"
            id="completed"
            checked={completed}
            onChange={(e) => setCompleted(e.target.checked)}
            className="h-4 w-4 text-violet-600 focus:ring-violet-500 border-slate-300 rounded"
          />
          <label htmlFor="completed" className={`ml-2 block text-sm ${darkMode ? 'text-slate-300' : 'text-slate-700'}`}>
            Mark as completed
          </label>
        </div>
      )}
      
      {/* Subtasks Section */}
      <div className="mb-5">
        <h3 className={`text-md font-medium mb-2 flex items-center ${darkMode ? 'text-slate-300' : 'text-slate-700'}`}>
          <ListChecks className={`h-4 w-4 mr-1.5 ${darkMode ? 'text-slate-400' : 'text-slate-500'}`} />
          Subtasks
        </h3>
        <div className="flex items-center mb-3">
          <input
            type="text"
            value={newSubtask}
            onChange={(e) => setNewSubtask(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Add a subtask"
            className={`flex-grow form-input rounded-r-none ${
              darkMode 
                ? 'bg-slate-700 border-slate-600 text-white focus:ring-violet-500' 
                : 'bg-white border-slate-300 text-slate-900 focus:ring-violet-500'
            }`}
          />
          <button
            type="button"
            onClick={addSubtask}
            className="btn-primary text-white px-3 py-2 rounded-l-none rounded-r-md"
          >
            <Plus className="h-5 w-5" />
          </button>
        </div>
        
        {subtasks.length > 0 ? (
          <ul className={`space-y-2 max-h-40 overflow-y-auto p-3 rounded-md ${
            darkMode ? 'bg-slate-700' : 'bg-slate-50'
          }`}>
            {subtasks.map(subtask => (
              <li 
                key={subtask.id} 
                className={`flex items-center justify-between p-2 rounded-lg shadow-sm transition-all duration-200 ${
                  darkMode 
                    ? 'bg-slate-800 hover:bg-slate-700' 
                    : 'bg-white hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center">
                  <button
                    type="button"
                    onClick={() => toggleSubtaskCompletion(subtask.id)}
                    className={`mr-2 focus:outline-none transition-colors ${
                      darkMode ? 'text-slate-400 hover:text-violet-400' : 'text-slate-500 hover:text-violet-600'
                    }`}
                  >
                    <CheckCircle2 className={`h-5 w-5 ${
                      subtask.completed 
                        ? 'text-green-500 dark:text-green-400' 
                        : darkMode ? 'text-slate-600' : 'text-slate-300'
                    }`} />
                  </button>
                  <span className={`${
                    subtask.completed 
                      ? 'line-through ' + (darkMode ? 'text-slate-500' : 'text-slate-500') 
                      : darkMode ? 'text-slate-300' : 'text-slate-700'
                  }`}>
                    {subtask.title}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => removeSubtask(subtask.id)}
                  className={`p-1 rounded-full transition-colors ${
                    darkMode 
                      ? 'text-slate-400 hover:text-rose-400 hover:bg-slate-700' 
                      : 'text-slate-400 hover:text-rose-500 hover:bg-slate-100'
                  }`}
                >
                  <X className="h-4 w-4" />
                </button>
              </li>
            ))}
          </ul>
        ) : (
          <p className={`text-sm italic ${darkMode ? 'text-slate-500' : 'text-slate-500'}`}>
            No subtasks added yet
          </p>
        )}
      </div>
      
      <div className={`flex justify-end space-x-3 mt-6 pt-4 border-t ${darkMode ? 'border-slate-700' : 'border-slate-200'}`}>
        <button
          type="button"
          onClick={onCancel}
          className={`btn-secondary px-4 py-2 rounded-lg ${
            darkMode 
              ? 'bg-slate-700 text-slate-200 hover:bg-slate-600' 
              : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
          }`}
        >
          Cancel
        </button>
        <button
          type="submit"
          className="btn-primary text-white px-4 py-2 rounded-lg"
        >
          {initialTask ? 'Update Task' : 'Create Task'}
        </button>
      </div>
    </form>
  );
};

export default TaskForm;