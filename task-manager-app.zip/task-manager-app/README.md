# Task Manager App

A modern task management application built with React, TypeScript, and Tailwind CSS, featuring a mock API for CRUD operations and a responsive user interface.

## Features

- Create, edit, delete, and mark tasks as completed
- Each task includes a title, description, due date, and priority level
- Sort tasks by due date, priority, or completion status
- Filter tasks by completion status
- Progress bar indicating the percentage of completed tasks
- Responsive design for both desktop and mobile
- **Mock API Integration** using JSONPlaceholder for simulating CRUD operations
- Basic error handling for API requests

## Technologies Used

- React (Vite-based setup)
- TypeScript
- Tailwind CSS
- JSONPlaceholder (Mock API)
- UUID for unique ID generation
- Lucide React (icons)

## Getting Started

### Prerequisites

- Node.js (v14 or higher)
- npm or yarn

### Installation

1. Clone the repository:
```bash
git clone https://github.com/hhenok45/task-manager-app.git
cd task-manager-app
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

4. Open your browser and navigate to `http://localhost:5173`

## Mock API Integration

This application interacts with a mock API using **JSONPlaceholder** (`https://jsonplaceholder.typicode.com/`) to simulate server interactions:

- **Fetch Tasks:** Retrieves a list of tasks from the mock API
- **Create a Task:** Adds a new task to the list
- **Update a Task:** Edits existing task details
- **Delete a Task:** Removes a task from the list
- **Error Handling:** Displays messages when API requests fail

## Build for Production

```bash
npm run build
```

## Deployment

This app is deployed on **Netlify**.
[Live Demo](https://charming-sfogliatella-d6864f.netlify.app/)

## Project Structure

```
task-manager-app/
├── public/
├── src/
│   ├── api/
│   │   └── taskApi.ts
│   ├── components/
│   │   ├── Modal.tsx
│   │   ├── TaskControls.tsx
│   │   ├── TaskForm.tsx
│   │   ├── TaskItem.tsx
│   │   └── TaskList.tsx
│   ├── types/
│   │   └── index.ts
│   ├── App.tsx
│   ├── index.css
│   └── main.tsx
├── package.json
├── README.md
└── ...
```

## Submission Details

- **GitHub Repository:** [GitHub Repo](https://github.com/hhenok45/task-manager-app)
- **Deployed Application:** [Live Demo](https://charming-sfogliatella-d6864f.netlify.app/)

